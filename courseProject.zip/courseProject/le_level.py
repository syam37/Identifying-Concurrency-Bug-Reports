#-*- codeing = utf-8 -*-
#@Time : 5/23/2022 8:24 PM
#@Author : Shao
#@File : le_level.py
#@Software : PyCharm
import sets


def identify(nlp, sent):
    doc = nlp(sent)
    CBG, CME, CTR, SYB, POP, API, EXC, PSM, AOT, NEG = False, False, False, False, False, False, False, False, False, False
    for token in doc:
        if str(token.pos_) == 'NOUN':
            if str(token.lemma_) in sets.CBG:
                CBG = True
            elif str(token.lemma_) in sets.CTR:
                CTR = True
            elif str(token.lemma_) in sets.CME:
                CME = True
            elif str(token.lemma_) in sets.SYB:
                SYB = True
        elif str(token.pos_) == 'VERB':
            if str(token.lemma_) in sets.POP:
                POP = True
            elif str(token.lemma_) in sets.PSM:
                PSM = True
        else:
            if str(token.lemma_) in sets.AOT:
                AOT = True
            elif str(token.lemma_) in sets.API:
                API = True
            elif str(token.lemma_) in sets.EXC:
                EXC = True
            elif str(token.lemma_) in sets.NEG:
                NEG = True
    if CBG:
        if CME:
            return 1
        elif SYB:
            return 2
    if CME:
        if POP:
            if NEG:
                return 8
            else:
                return 3
        elif PSM:
            if AOT:
                return 9
            else:
                return 4
        elif SYB:
            return 5
    if API:
        if PSM:
            if AOT:
                return 9
            else:
                return 4
        elif EXC:
            return 7
    if CTR and SYB:
        return 6
    return None
