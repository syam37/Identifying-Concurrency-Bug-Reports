# -*- codeing = utf-8 -*-
# @Time : 5/23/2022 8:33 PM
# @Author : Shao
# @File : se_level.py
# @Software : PyCharm
import spacy

import le_level
import sets

subject = ['nsubj', 'nsubjpass']
obj = ['dobj', 'bobj']


def identify(nlp, sent):
    doc = nlp(sent)
    index = le_level.identify(nlp, sent)
    if index == 1:
        cbg_1, cme_1, cbg_2, cme_2, cbg_3, cme_3, cbg_4, cme_4 = False, False, False, False, False, False, False, False
        for token in doc:
            if str(token.lemma_) in sets.CBG:
                if str(token.dep_) == 'dobj':
                    cbg_1 = True
                elif str(token.dep_) == 'ROOT':
                    cbg_2, cbg_4 = True, True
                elif str(token.dep_) in ['pobj', 'nsubj']:
                    cbg_3 = True
            elif str(token.lemma_) in sets.CME:
                if str(token.dep_) in subject:
                    cme_1 = True
                elif str(token.dep_) == 'dobj':
                    cme_2 = True
                elif str(token.dep_) in obj:
                    cme_3 = True
                elif str(token.dep_) == 'compound':
                    cme_4 = True
        if cbg_1 and cme_1:
            return 1
        if cbg_2 and cme_2:
            return 2
        if cbg_3 and cme_3:
            return 3
        if cbg_4 and cme_4:
            return 4
    elif index == 2:
        cbg_1, syb_1, cbg_2, syb_2 = False, False, False, False
        for token in doc:
            if str(token.lemma_) in sets.CBG:
                if str(token.dep_) == 'dobj':
                    cbg_1 = True
                elif str(token.dep_) == 'compound':
                    cbg_2 = True
            elif str(token.lemma_) in sets.SYB:
                if str(token.dep_) in obj:
                    syb_1, syb_2 = True, True
        if cbg_1 and syb_1:
            return 5
        if cbg_2 and syb_2:
            return 6
    elif index == 3:
        cme_1, cme_2, cme_3, pop_1, pop_2, pop_3 = False, False, False, False, False, False
        for token in doc:
            if str(token.lemma_) in sets.CME:
                if str(token.dep_) in ['dobj', 'pobj', 'nsubj']:
                    cme_1 = True
                elif str(token.dep_) == 'nsubjpass':
                    cme_2 = True
                elif str(token.dep_) == 'compound':
                    cme_3 = True
            elif str(token.lemma_) in sets.POP:
                if str(token.dep_) in ['ROOT', 'advcl', 'acl']:
                    pop_1 = True
                elif str(token.dep_) == 'xcomp':
                    pop_2 = True
                elif str(token.dep_) == 'compound':
                    pop_3 = True
        if cme_1 and pop_1:
            return 7
        if cme_2 and pop_2:
            return 8
        if cme_3 and pop_2:
            return 9
    elif index == 4:
        cme_1, cme_2, cme_3, cme_4, cme_5, psm_1, psm_2, psm_3, psm_4, psm_5 = False, False, False, False, False, \
                                                                               False, False, False, False, False
        for token in doc:
            if str(token.lemma_) in sets.CME or str(token.lemma_) in sets.API:
                if str(token.dep_) == 'nsubjpass':
                    cme_1, cme_4 = True, True
                elif str(token.dep_) in ['compound', 'ccomp']:
                    cme_2 = True
                elif str(token.dep_) == 'dobj':
                    cme_3, cme_5 = True, True
                elif str(token.dep_) == 'nsubj':
                    cme_5 = True
            elif str(token.lemma_) in sets.PSM:
                if str(token.dep_) == 'ROOT':
                    psm_1, psm_2, psm_3 = True, True, True
                elif str(token.dep_) in obj:
                    psm_2 = True
                elif str(token.dep_) in subject:
                    psm_3 = True
                elif str(token.dep_) == 'advcl':
                    psm_4 = True
                elif str(token.dep_) in ['conj', 'ccomp']:
                    psm_5 = True
        if cme_1 and psm_1:
            return 10
        if cme_2 and psm_2:
            return 11
        if cme_3 and psm_3:
            return 12
        if cme_4 and psm_4:
            return 13
        if cme_5 and psm_5:
            return 14
    elif index == 5:
        cme_1, cme_2, cme_3, syb_1, syb_2, syb_3 = False, False, False, False, False, False
        for token in doc:
            if str(token.lemma_) in sets.CME:
                if str(token.dep_) == 'dobj':
                    cme_1 = True
                elif str(token.dep_) == 'compound':
                    cme_2 = True
                elif str(token.dep_) in ['nsubj', 'pobj', 'ROOT']:
                    cme_3 = True
            elif str(token.lemma_) in sets.SYB:
                if str(token.dep_) == 'compound':
                    syb_1 = True
                elif str(token.dep_) in obj:
                    syb_2, syb_3 = True, True
                elif str(token.dep_) == 'ROOT':
                    syb_2 = True
        if cme_1 and syb_1:
            return 15
        if cme_2 and syb_2:
            return 16
        if cme_3 and syb_3:
            return 17
    elif index == 6:
        ctr_1, ctr_2, ctr_3, syb_1, syb_2, syb_3 = False, False, False, False, False, False
        for token in doc:
            if str(token.lemma_) in sets.CTR:
                if str(token.dep_) == 'dobj':
                    ctr_1 = True
                elif str(token.dep_) == 'compound':
                    ctr_2 = True
                elif str(token.dep_) in ['nsubj', 'pobj', 'ROOT']:
                    ctr_3 = True
            elif str(token.lemma_) in sets.SYB:
                if str(token.dep_) == 'compound':
                    syb_1 = True
                elif str(token.dep_) in obj:
                    syb_2, syb_3 = True, True
                elif str(token.dep_) == 'ROOT':
                    syb_2 = True
        if ctr_1 and syb_1:
            return 18
        if ctr_2 and syb_2:
            return 19
        if ctr_3 and syb_3:
            return 20
    elif index == 7:
        exc_1, exc_2, api_1, api_2 = False, False, False, False
        for token in doc:
            if str(token.lemma_) in sets.EXC:
                if str(token.dep_) == 'ROOT':
                    exc_1, exc_2 = True, True
            elif str(token.lemma_) in sets.API:
                if str(token.dep_) == 'compound':
                    api_1 = True
                elif str(token.dep_) in obj:
                    api_2 = True
        if exc_1 and api_1:
            return 21
        elif exc_2 and api_2:
            return 22
    elif index == 8:
        cme_1, cme_2, cme_3, cme_4, pop_1, pop_2, pop_3, pop_4, neg = False, False, False, False, False, \
                                                                      False, False, False, False
        for token in doc:
            if str(token.lemma_) in sets.CME:
                if str(token.dep_) == 'dobj':
                    cme_1, cme_2 = True, True
                elif str(token.dep_) == 'nsubj':
                    cme_2 = True
                elif str(token.dep_) == 'pobj':
                    cme_3, cme_4 = True, True
            elif str(token.lemma_) in sets.POP:
                if str(token.dep_) == 'ROOT':
                    pop_1 = True
                elif str(token.dep_) == 'advcl':
                    pop_2 = True
                elif str(token.dep_) == 'nsubjpass':
                    pop_3 = True
                elif str(token.dep_) == 'relcl':
                    pop_4 = True
            elif str(token.lemma_) in sets.NEG:
                if str(token.dep_) == 'neg':
                    neg = True
        if neg:
            if cme_1 and pop_1:
                return 23
            if cme_2 and pop_2:
                return 24
            if cme_3 and pop_3:
                return 25
            if cme_4 and pop_4:
                return 26
    elif index == 9:
        cme_1, cme_2, psm_1, psm_2, aot = False, False, False, False, False
        for token in doc:
            if str(token.lemma_) in sets.CME:
                if str(token.dep_) in subject:
                    cme_1, cme_2 = True, True
                elif str(token.dep_) == 'dobj':
                    cme_2 = True
            elif str(token.lemma_) in sets.PSM:
                if str(token.dep_) == 'ROOT':
                    psm_1 = True
                elif str(token.dep_) == 'advcl':
                    psm_2 = True
            elif str(token.lemma_) in sets.AOT:
                if str(token.dep_) == 'advmod':
                    aot = True
        if aot:
            if cme_1 and psm_1:
                return 27
            if cme_2 and psm_2:
                return 28
    return None
