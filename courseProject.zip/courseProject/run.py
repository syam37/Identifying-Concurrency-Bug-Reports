#-*- codeing = utf-8 -*-
#@Time : 5/24/2022 5:14 PM
#@Author : Shao
#@File : run.py
#@Software : PyCharm
import spacy

import kw_level
import le_level
import se_level

nlp = spacy.load("en_core_web_sm")
#conSents = open("dataset/dataset1/redisson/redisson_pos.txt", encoding='utf-8')
conSents = open("dataset/dataset1/redisson/redisson_neg.txt", encoding='utf-8')
#conSents = open("dataset/dataset1/grpc/grpc_pos.txt", encoding='utf-8')
# conSents = open("dataset/dataset1/grpc/grpc_neg.txt", encoding='utf-8')
# conSents = open("dataset/dataset1/vertx/vertx_pos.txt", encoding='utf-8')
#conSents = open("dataset/dataset1/vertx/vertx_neg.txt", encoding='utf-8')
wre = open("evaluation/weka/data/vertx.txt", 'w')

result = []


lineList = []
for li in conSents:
    lineList.append(li)

for ll in lineList:
    doc = nlp(ll)
    sents = []
    rer = []
    # for i in range(28):
    # for i in range(9):
    for i in range(32):
        rer.append(0)
    for sent in doc.sents:
        sents.append(str(sent))
    for se in sents:
        # kw_index = kw_level.identify(nlp, se)
        # if kw_index is not None:
        #     rer[kw_index] = 1
        # kw_index = le_level.identify(nlp, se)
        # if kw_index is not None:
        #     rer[kw_index-1] = 1
        kw_index = se_level.identify(nlp, se)
        if kw_index is not None:
            rer[kw_index-1] = 1
    result.append(rer)

# k = 1
# for re in result:
#     flag = True
#     for r in re:
#         if r == 1:
#             flag = False
#     if flag:
#         print(k)
#     k += 1
for re in result:
    print(re)
    #re.append(1)
    wre.write(str(re))
    wre.write('\n')

