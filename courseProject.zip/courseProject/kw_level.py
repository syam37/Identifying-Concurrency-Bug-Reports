# -*- codeing = utf-8 -*-
# @Time : 5/23/2022 8:24 PM
# @Author : Shao
# @File : kw_level.py
# @Software : PyCharm
import sets


def identify(nlp, sent):
    doc = nlp(sent)
    for token in doc:
        if str(token.lemma_).lower() in sets.CB:
            index = sets.CB.index(str(token.lemma_).lower())
            return index
        elif str(token.lemma_).lower() in sets.CT:
            index = sets.CT.index(str(token.lemma_).lower())
            return index + 5
        elif str(token.lemma_).lower() in sets.CM:
            index = sets.CM.index(str(token.lemma_).lower())
            return index + 14
    return None
